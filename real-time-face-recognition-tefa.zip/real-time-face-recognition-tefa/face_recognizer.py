import cv2
import numpy as np
import json
import os
import gspread 

from oauth2client.service_account import ServiceAccountCredentials

from pprint import pprint as pp
from oauth2client.service_account import ServiceAccountCredentials

from pprint import pprint as pp

scope = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]

creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json",scope)
client = gspread.authorize(creds)
sheet = client.open("Absensi").sheet1



if __name__ == "__main__":
    
    # Create LBPH Face Recognizer
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    # Load the trained model
    recognizer.read('trainer.yml')
    print(recognizer)
    # Path to the Haar cascade file for face detection
    face_cascade_Path = "haarcascade_frontalface_default.xml"
    
    # Create a face cascade classifier
    faceCascade = cv2.CascadeClassifier(face_cascade_Path)
    
    # Font for displaying text on the image
    font = cv2.FONT_HERSHEY_SIMPLEX
    
    # Initialize user IDs and associated names
    id = 0
    # Don't forget to add names associated with user IDs
    names = ['None']
    with open('names.json', 'r') as fs:
        names = json.load(fs)
        names = list(names.values())
    
    # Video Capture from the default camera (camera index 0)
    cam = cv2.VideoCapture(0)
    cam.set(3, 640)  # Set width
    cam.set(4, 480)  # Set height
    
    # Minimum width and height for the window size to be recognized as a face
    minW = 0.1 * cam.get(3)
    minH = 0.1 * cam.get(4)
    
    while True:
        # Read a frame from the camera
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
        # Detect faces in the frame
        faces = faceCascade.detectMultiScale(
            gray,
            scaleFactor=1.2,
            minNeighbors=5,
            minSize=(int(minW), int(minH)),
        )
    
        for (x, y, w, h) in faces:

            # Draw a rectangle around the detected face
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
    
            # Recognize the face using the trained model
            id, confidence = recognizer.predict(gray[y:y + h, x:x + w])
            # Proba greater than 51
			
			
			 


            if confidence > 51:
                try:
                    # Recognized face
                    name = names[id]
					
				    #Getting data from the sheet
                    data = sheet.get_all_records()
                    pp(data)
					#Get the specific row, column and cell from the sheet
                    row = sheet.row_values(3)
                    col = sheet.col_values(3)
                    #cell = sheet.cell(1,2).value  # kolom 1 baris 2
                    cell = sheet.cell(2,1).value


                    pp(cell)
                  
                    a_nmr = name
                    a_name = name
                    a_order = name
                   
                    #Inserting data in your sheet 

                    insertRow = [a_name,"hadir","",""]
                    sheet.insert_row(insertRow,2)
                    print("The row has been added")
					


				
                    confidence = "  {0}%".format(round(confidence))
                except IndexError as e:
                    name = "Who are you?"
                    confidence = "N/A"
            else:
                # Unknown face
                name = "Who are you?"
                confidence = "N/A"
    
            # Display the recognized name and confidence level on the image
            cv2.putText(img, "saya adalah : "+name, (x + 5, y - 5), font, 1, (255, 255, 255), 2)
            cv2.putText(img, confidence, (x + 5, y + h - 5), font, 1, (255, 255, 0), 1)
    
        # Display the image with rectangles around faces
        cv2.imshow('camera', img)
    
        # Press Escape to exit the webcam / program
        k = cv2.waitKey(10) & 0xff
        if k == 27:
            break
    
	 
   




	
	
    print("\n [INFO] Exiting Program.")




# Release the camera
cam.release()




		 
		 
# Close all OpenCV windows
cv2.destroyAllWindows()
